import DashboardController from './DashboardController'
import ProductCreateController from './ProductCreateController'
import ProductController from './ProductController'

const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    ProductCreateController: Object.assign(ProductCreateController, ProductCreateController),
    ProductController: Object.assign(ProductController, ProductController),
}

export default Admin