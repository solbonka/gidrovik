import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
export const characteristics = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: characteristics.url(args, options),
    method: 'get',
})

characteristics.definition = {
    methods: ["get","head"],
    url: '/admin/products/categories/{category}/characteristics',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
characteristics.url = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: args.category,
    }

    return characteristics.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
characteristics.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: characteristics.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
characteristics.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: characteristics.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
const characteristicsForm = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: characteristics.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
characteristicsForm.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: characteristics.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Admin\ProductCreateController::characteristics
* @see app/Http/Controllers/Admin/ProductCreateController.php:48
* @route '/admin/products/categories/{category}/characteristics'
*/
characteristicsForm.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: characteristics.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

characteristics.form = characteristicsForm

const categories = {
    characteristics: Object.assign(characteristics, characteristics),
}

export default categories