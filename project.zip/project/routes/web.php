<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ProductCreateController;

Route::inertia('/', 'Welcome')->name('home');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::inertia('dashboard', 'Dashboard')->name('dashboard');
});

require __DIR__.'/settings.php';

Route::middleware('auth')
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/', DashboardController::class)
            ->name('dashboard');
        Route::get('/products/create', [
            ProductCreateController::class,
            'create',
        ])->name('products.create');

        Route::get('/products/categories/{category}/characteristics', [
            ProductCreateController::class,
            'characteristics',
        ])->name('products.categories.characteristics');

        Route::post('/products', [
            ProductController::class,
            'store',
        ])->name('products.store');
    });
