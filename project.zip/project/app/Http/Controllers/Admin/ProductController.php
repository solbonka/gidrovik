<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreProductRequest;
use App\Services\Admin\ProductService;
use Illuminate\Http\RedirectResponse;

class ProductController extends Controller
{
    public function store(
        StoreProductRequest $request,
        ProductService $productService
    ): RedirectResponse {
        $product = $productService->create(
            $request->validated()
        );

        return redirect()
            ->route('admin.products.edit', $product)
            ->with('success', 'Товар успешно создан.');
    }
}
