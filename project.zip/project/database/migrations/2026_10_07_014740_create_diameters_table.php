<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('diameters', function (Blueprint $table) {
            $table->id();

            $table->unsignedInteger('value');
            $table->string('unit')->default('mm');

            $table->boolean('is_active')->default(true);

            $table->timestamps();

            $table->unique([
                'value',
                'unit',
            ]);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('diameters');
    }
};
